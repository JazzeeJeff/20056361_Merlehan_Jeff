<!DOCTYPE html>
<html>
<head>
<title>noahpetclinic</title>
<meta name="description" content="" />
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/templatemo_style.css" rel="stylesheet">
<link rel="stylesheet" href="css/templatemo_misc.css">
<link rel="stylesheet" href="css/nivo-slider.css">
<link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" />
<link href="http://fonts.googleapis.com/css?family=Raleway:400,100,600" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/JavaScript" src="js/slimbox2.js"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "templatemo_flicker", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>
<body>
<header>
  <!-- start menu -->
  <div id="templatemo_home">
    <div class="templatemo_top">
      <div class="container templatemo_container">
        <div class="row">
          <div class="col-sm-3 col-md-3">
            <div class="logo"> <a href="#"><img src="images/Unedited img/npclogov2small.jpg" alt=""/></a> </div>
          </div>
          <div class="col-sm-9 col-md-9 templatemo_col9">
            <div id="top-menu">
              <nav class="mainMenu">
                <ul class="nav">
                  <li><a class="menu" href="#templatemo_home">Home</a></li>
                  <li><a class="menu" href="#templatemo_about">About</a></li>
                  <li><a class="menu" href="#templatemo_blog">Services</a></li>
                  <li><a class="menu" href="#templatemo_portfolio">Gallery</a></li>
                  <li><a class="menu" href="#templatemo_contact">Contact</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
  <!-- end menu -->
  <div  id="slider"  class="nivoSlider templatemo_slider"> <a href="#"><img src="images/slider/Cat-1920x700.jpg" alt="slide 1" /></a> <a href="#"><img src="images/slider/shiba-inu.jpg" alt="slide 2" /></a> <a href="#"><img src="images/slider/bunny1.jpg" alt="slide 3" /></a> </div>
  <div class="templatemo_caption"> </div>
</header>
<div class="templatemo_lightgrey_about" id="templatemo_about">
  <div class="container"> </div>
</div>
<div class="clear"></div>
<div class="templatemo_reasonbg">
  <h2>Why choose us?</h2>
  <p>At NPC we treat all pets as part of the family and this means we provide the best care possible. We have been looking after pets since 1989 in the Greater Manchester area. We believe in a sense of community and take pride in providing excellent service that you can rely on. We are a family run business and we treat everyone as part of our family.
  </p>
  <div class="clear height10"></div>
  <p>Our excellent team have a wealth of experience between them that specialise in dogs, but we treat creatures of all shapes and sizes. Be it our admin staff, nurses or doctors, we make sure we are trained to the higest standard. Sparing no expense, we continuously invest in our staff and clinic to make sure we have the best equipment and personel. We pride ourselves on providing quick and efficient care at a reasonable price. Since we opening in 1989 we have treated a whole host of ailments so we are confident that we can look after you.
  </p>
  <div class="clear height20"></div>
</div>
<div class="clear"></div>
<!--Services Start-->
<div class="templatemo_blog" id="templatemo_blog">
  <h2>Services</h2>
  <p>Check out some of our range of services.</p>
  <div class="clear"></div>
  <div class="container">
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="clear"></div>
      <img src="images/gallerydogemergency.jpg" alt="services image 1">
      <div class="clear"></div>
      <div class="templatemo_blogtext"> <span class="left">Emergency Surgery</span> <span class="right"> </span> </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="clear"></div>
      <img src="images/gallerycatmicrochip.jpg" alt="services image 2">
      <div class="clear"></div>
      <div class="templatemo_blogtext"> <span class="left">Microchipping</span> <span class="right"> </span> </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 templatemo_margintop10">
      <div class="clear"></div>
      <img src="images/gallerypetvaccinations.jpg" alt="services image 3">
      <div class="clear"></div>
      <div class="templatemo_blogtext"> <span class="left">Vaccinations</span> <span class="right"> </span> </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 templatemo_margintop10">
      <div class="clear"></div>
      <img src="images/gallerydogdental.jpg" alt="services image 4">
      <div class="clear"></div>
      <div class="templatemo_blogtext"> <span class="left">Dental Care</span> <span class="right"> </span> </div>
    </div>
	<form action='index.php' method='GET'>



Please select a service to enquire: <Select name='yyy' id="select">
<option>Select a service...</option>
<option>Consultation</option>
<option>Surgery </option>
<option>Microchipping </option>
<option>Vaccinations </option>		
<option>Dental checkup</option>	
<option>Pet Insurance</option>
<option>Neutering</option>
<option>Emergency</option>	

 </select>

 <input type='submit' value='cost' id="cost">

 </form>
 
<?php
$con = mysqli_connect("localhost","root","", "npc");
	if (!$con) {
		die ("Failed");
	}
	
	if (isset($_GET['yyy']))
	{
	$a = $_GET['yyy'];

	
$sql = "SELECT * FROM npc where service='$a' ";
	$result = $con->query($sql);
	if ($result->num_rows > 0) { 
		while($row = $result->fetch_assoc()) {  
			
			echo ("The price for ".$row["service"]. " is £".$row["price"]." and is currently performed by ".$row["staff"]." on ".$row["days"].".<br>");
		} 
	}
    else {
		echo "Service not found, please contact the clinic."; 
	} 

	}
	
	

?>

  </div>
  
</div>

<!--Services End-->
<!--Gallery Start-->
<div class="templatemo_portfolio" id="templatemo_portfolio">
  <h2>Gallery</h2>
  <p>Come say hello to some of our happy customers!</p>
  <div class="container">
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/gallerydog.jpg" alt="portfolio 1">
          <div class="overlay-p"> <a href="images/portfolio/gallerydog.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Tommy</li>
            </ul>
            </a> </div>
        </div>
        <!-- /.gallery-thumb --> 
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/gallerycat.jpg" alt="portfolio 2">
          <div class="overlay-p"> <a href="images/portfolio/gallerycat.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Musket</li>
            </ul>
            </a> </div>
        </div>
        <!-- /.gallery-thumb -->
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/gallerybirds.jpg" alt="portfolio 3">
          <div class="overlay-p"> <a href="images/portfolio/gallerybirds.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Bill and Ted</li>
            </ul>
            </a> </div>
        </div>
        <!-- /.gallery-thumb --> 
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/gallerycalf.jpg" alt="portfolio 4">
          <div class="overlay-p"> <a href="images/portfolio/gallerycalf.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Harry</li>
            </ul>
            </a> </div>
        </div>
        <!-- /.gallery-thumb -->         
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 col-md-offset-3">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/gallerybat.jpg" alt="portfolio 5">
          <div class="overlay-p"> <a href="images/portfolio/gallerybat.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Bat</li>
            </ul>
            </a> </div>
        </div>
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 col-md-offset-0">
      <div class="portfolio-item">
        <div class="portfolio-thumb"> <img src="images/portfolio/galleryraccoon.jpg" alt="portfolio 5">
          <div class="overlay-p"> <a href="images/portfolio/galleryraccoon.jpg" data-rel="lightbox[portfolio]">
            <ul>
              <li>Sly Cooper</li>
            </ul>
          </a></div>
        </div>
      </div>
    </div>
<!-- /.gallery-thumb -->
	  
  </div>
  <div class="clear"></div>
  <div class="container"> </div>
</div>
<!--gallery End-->
<div class="clear"></div>
<!--Contact Start -->
<div class="templatemo_lightgrey" id="templatemo_contact">
  <div class="templatemo_paracenter">
    <h2>Contact us</h2>
	<P>Enter your details below and we will be in touch!</P>
  </div>
  <div class="clear">
	</div>
  <div class="container">
    <div class="templatemo_paracenter"> </div>
    <div class="clear"></div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="templatemo_maps">
            <div class="fluid-wrapper">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d593.623102480199!2d-2.2649410707619295!3d53.47753109875044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487bb1dfff448471%3A0x5c9b4d9ed5a51471!2sSalford%20M5%203TP!5e0!3m2!1sen!2suk!4v1602952365696!5m2!1sen!2suk"></iframe>
          
			  </div>
          </div>
        </div>
        <div class="container">
          <div class="row">
            <div class="col-md-3">
              <form action="" method="post">               
                <div class="form-group">					
                <input name="first_name" type="text" class="form-control" id="first_name" placeholder="Your First Name" maxlength="30">
                </div>
                <div class="form-group">
                <input name="last_name" type="text" class="form-control" id="last_name" placeholder="Your Last Name" maxlength="30">
                </div>
                <div class="form-group">
                <input name="email" type="text" class="form-control" id="email" placeholder="Your Email" maxlength="40">				
                </div>
				<div class="form-group">
                <input name="phone" type="text" class="form-control" id="phone" placeholder="Your Phone Number" maxlength="40">				
                </div>
<button type="submit" class="btn btn-primary">Send</button>
              
            </div>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "npcdetails");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
if (isset($link, $_REQUEST["first_name"])) {
// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST["first_name"]);
$last_name = mysqli_real_escape_string($link, $_REQUEST["last_name"]);
$email = mysqli_real_escape_string($link, $_REQUEST["email"]);
$phone = mysqli_real_escape_string($link, $_REQUEST["phone"]);

// Attempt insert query execution
$sql = "INSERT INTO npcdetails (first_name, last_name, email, phone) VALUES ('$first_name', '$last_name', '$email', '$phone')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
} 
// Close connection
mysqli_close($link);
?>			
            <div class="col-md-9">
              <div class="txtarea">

              </div>
		    </form>
            </div>
          <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 col-md-offset-6">
            <h2>Contact</h2>
            <span class="right col-xs-11">Regent Retail Park, Salford, M5 3TP</span>
            <div class="clear height10"></div>
            <span class="right col-xs-11">0161-1234567</span>
            <div class="clear height10"></div>
            <span class="right col-xs-11">contact@npc.co.uk</span>
            <div class="clear height10"></div>
            <span class="right col-xs-11">www.noahspetclinic.com</span>
            <div class="clear"></div>
          </div>
          </div>
      </div>
    </div>
  </div>
  </div>
</div>


<!--Contact End-->
<!--Footer Start--><!--Footer End-->
<!-- Bottom Start -->
<div class="templatemo_bottom">
  <div class="container">
    <div class="row">
      <div class="left"> Copyright © 2020 <a href="#">Noah's Pet Clinic</a> . Design: <a rel="nofollow" href="#">Jeff Merlehan</a></div>
      <div class="right"> </div>
    </div>
  </div>
</div>
<!-- Bottom End -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- <script src="https://code.jquery.com/jquery.js"></script> -->
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.cycle2.min.js"></script>
<script src="js/jquery.cycle2.carousel.min.js"></script>
<script src="js/jquery.nivo.slider.pack.js"></script>
<script>$.fn.cycle.defaults.autoSelector = '.slideshow';</script>
<script type="text/javascript">
      $(function(){
          var default_view = 'grid';
          if($.cookie('view') !== 'undefined'){
              $.cookie('view', default_view, { expires: 7, path: '/' });
          } 
          function get_grid(){
              $('.list').removeClass('list-active');
              $('.grid').addClass('grid-active');
              $('.prod-cnt').animate({opacity:0},function(){
                  $('.prod-cnt').removeClass('dbox-list');
                  $('.prod-cnt').addClass('dbox');
                  $('.prod-cnt').stop().animate({opacity:1});
              });
          }
          function get_list(){
              $('.grid').removeClass('grid-active');
              $('.list').addClass('list-active');
              $('.prod-cnt').animate({opacity:0},function(){
                  $('.prod-cnt').removeClass('dbox');
                  $('.prod-cnt').addClass('dbox-list');
                  $('.prod-cnt').stop().animate({opacity:1});
              });
          }
          if($.cookie('view') == 'list'){ 
              $('.grid').removeClass('grid-active');
              $('.list').addClass('list-active');
              $('.prod-cnt').animate({opacity:0});
              $('.prod-cnt').removeClass('dbox');
              $('.prod-cnt').addClass('dbox-list');
              $('.prod-cnt').stop().animate({opacity:1}); 
          } 

          if($.cookie('view') == 'grid'){ 
              $('.list').removeClass('list-active');
              $('.grid').addClass('grid-active');
              $('.prod-cnt').animate({opacity:0});
                  $('.prod-cnt').removeClass('dboxlist');
                  $('.prod-cnt').addClass('dbox');
                  $('.prod-cnt').stop().animate({opacity:1});
          }

          $('#list').click(function(){   
              $.cookie('view', 'list'); 
              get_list()
          });

          $('#grid').click(function(){ 
              $.cookie('view', 'grid'); 
              get_grid();
          });

          /* filter */
          $('.menuSwitch ul li').click(function(){
              var CategoryID = $(this).attr('category');
              $('.menuSwitch ul li').removeClass('cat-active');
              $(this).addClass('cat-active');
              
              $('.prod-cnt').each(function(){
                  if(($(this).hasClass(CategoryID)) == false){
                     $(this).css({'display':'none'});
                  };
              });
              $('.'+CategoryID).fadeIn(); 
              
          });
      });
    </script>
<script src="js/jquery.singlePageNav.js"></script>
<script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
          prevText: '',
          nextText: '',
          controlNav: false,
        });
    });
    </script>
<script>
      $(document).ready(function(){

        // hide #back-top first
        $("#back-top").hide();
        
        // fade in #back-top
        $(function () {
          $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
              $('#back-top').fadeIn();
            } else {
              $('#back-top').fadeOut();
            }
          });

          // scroll body to 0px on click
          $('#back-top a').click(function () {
            $('body,html').animate({
              scrollTop: 0
            }, 800);
            return false;
          });
        });

      });
      </script>
<script type="text/javascript">
      <!--
          function toggle_visibility(id) {
             var e = document.getElementById(id);
             if(e.style.display == 'block'){
                e.style.display = 'none';
                $('#togg').text('show footer');
            }
             else {
                e.style.display = 'block';
                $('#togg').text('hide footer');
            }
          }
      //-->
      </script>
<script type="text/javascript">
      $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
          if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
              $('html,body').animate({
                scrollTop: target.offset().top
              }, 1000);
              return false;
            }
          }
        });
      });
      </script>
<script src="js/stickUp.min.js" type="text/javascript"></script>
<script type="text/javascript">
        //initiating jQuery
        jQuery(function($) {
          $(document).ready( function() {
            //enabling stickUp on the '.navbar-wrapper' class
            $('.mWrapper').stickUp();
          });
        });
      </script>
<script>
     $('a.menu').click(function(){
    $('a.menu').removeClass("active");
    $(this).addClass("active");
	});
      </script>
<script> <!-- scroll to specific id when click on menu -->
      	 // Cache selectors
var lastId,
    topMenu = $("#top-menu"),
    topMenuHeight = topMenu.outerHeight()+15,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function(){
      var item = $($(this).attr("href"));
      if (item.length) { return item; }
    });

// Bind click handler to menu items
// so we can get a fancy scroll animation
menuItems.click(function(e){
  var href = $(this).attr("href"),
      offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+1;
  $('html, body').stop().animate({ 
      scrollTop: offsetTop
  }, 300);
  e.preventDefault();
});

// Bind to scroll
$(window).scroll(function(){
   // Get container scroll position
   var fromTop = $(this).scrollTop()+topMenuHeight;
   
   // Get id of current scroll item
   var cur = scrollItems.map(function(){
     if ($(this).offset().top < fromTop)
       return this;
   });
   // Get the id of the current element
   cur = cur[cur.length-1];
   var id = cur && cur.length ? cur[0].id : "";
   
   if (lastId !== id) {
       lastId = id;
       // Set/remove active class
       menuItems
         .parent().removeClass("active")
         .end().filter("[href=#"+id+"]").parent().addClass("active");
   }                   
});
      </script>
</body>
</html>
